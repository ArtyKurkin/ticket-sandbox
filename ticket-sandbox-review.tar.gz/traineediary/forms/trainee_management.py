import secrets

from django import forms
from django.contrib.auth.models import User
from django.db import transaction
from django.utils import timezone

from sandbox.models import TraineeProfile

from ..models import (
    EntryType,
    TraineeJourney,
    TraineeStage,
)


class NewTraineeForm(forms.Form):
    first_name = forms.CharField(
        label="Имя",
        max_length=150,
    )

    last_name = forms.CharField(
        label="Фамилия",
        max_length=150,
    )

    username = forms.CharField(
        label="Логин (для входа в систему)",
        max_length=150,
    )

    entry_type = forms.ChoiceField(
        label="Тип входа",
        choices=(
            (
                EntryType.NEW_HIRE,
                "Новая адаптация",
            ),
            (
                EntryType.INTERNAL_TRANSFER,
                (
                    "Внутренний переход / "
                    "сотрудник из другого отдела"
                ),
            ),
        ),
        widget=forms.RadioSelect,
    )

    probation_start_date = forms.DateField(
        label="Дата старта ИС",
        required=False,
        initial=timezone.localdate,
        widget=forms.DateInput(
            attrs={
                "type": "date",
            },
        ),
    )

    current_stage = forms.ModelChoiceField(
        label="Текущий этап",
        required=False,
        queryset=(
            TraineeStage.objects
            .filter(is_active=True)
            .order_by("order")
        ),
        widget=forms.Select(
            attrs={
                "class": "form-select",
            },
        ),
    )

    comment = forms.CharField(
        label="Комментарий",
        required=False,
        widget=forms.Textarea(
            attrs={
                "rows": 3,
            },
        ),
    )

    def clean_username(self):
        username = self.cleaned_data[
            "username"
        ].strip()

        if User.objects.filter(
            username=username,
        ).exists():
            raise forms.ValidationError(
                "Такой логин уже занят.",
            )

        return username

    def clean(self):
        cleaned_data = super().clean()

        entry_type = cleaned_data.get(
            "entry_type",
        )
        probation_start_date = cleaned_data.get(
            "probation_start_date",
        )
        stage = cleaned_data.get(
            "current_stage",
        )

        if entry_type == EntryType.NEW_HIRE:
            if probation_start_date is None:
                self.add_error(
                    "probation_start_date",
                    "Укажи дату старта ИС.",
                )

            if (
                probation_start_date
                and probation_start_date
                > timezone.localdate()
            ):
                self.add_error(
                    "probation_start_date",
                    (
                        "Дата начала испытательного срока "
                        "не может быть в будущем."
                    ),
                )

            if stage is None:
                self.add_error(
                    "current_stage",
                    "Выбери текущий этап.",
                )

            if (
                stage is not None
                and not stage.applies_to_entry_type(
                    entry_type,
                )
            ):
                self.add_error(
                    "current_stage",
                    (
                        "Этот этап не применим "
                        "к выбранному типу входа."
                    ),
                )

        if entry_type == EntryType.INTERNAL_TRANSFER:
            # Эти данные не относятся к аккаунту
            # сотрудника до начала адаптации.
            cleaned_data["probation_start_date"] = None
            cleaned_data["current_stage"] = None
            cleaned_data["comment"] = ""

        return cleaned_data

    @transaction.atomic
    def save(
        self,
        *,
        changed_by=None,
    ):
        generated_password = secrets.token_urlsafe(
            9,
        )

        user = User.objects.create_user(
            username=self.cleaned_data[
                "username"
            ],
            first_name=self.cleaned_data[
                "first_name"
            ],
            last_name=self.cleaned_data[
                "last_name"
            ],
            password=generated_password,
        )

        TraineeProfile.objects.update_or_create(
            user=user,
            defaults={
                "level": TraineeProfile.Level.L1,
            },
        )

        entry_type = self.cleaned_data[
            "entry_type"
        ]

        if entry_type == EntryType.INTERNAL_TRANSFER:
            return (
                user,
                None,
                generated_password,
            )

        stage = self.cleaned_data[
            "current_stage"
        ]
        probation_start_date = self.cleaned_data[
            "probation_start_date"
        ]

        journey = TraineeJourney.objects.create(
            user=user,
            entry_type=entry_type,
            probation_start_date=(
                probation_start_date
            ),
            current_stage=stage,
            stage_started_at=(
                probation_start_date
            ),
            comment=self.cleaned_data.get(
                "comment",
                "",
            ),
        )

        # В проекте история может уже создаваться
        # при сохранении TraineeJourney.
        # Поэтому не создаём дубликат.
        initial_history = (
            journey.stage_history
            .filter(
                stage=stage,
                ended_at__isnull=True,
            )
            .first()
        )

        if initial_history is None:
            journey.stage_history.create(
                stage=stage,
                started_at=(
                    probation_start_date
                ),
                changed_by=changed_by,
            )
        elif (
            changed_by is not None
            and initial_history.changed_by_id is None
        ):
            initial_history.changed_by = changed_by
            initial_history.save(
                update_fields=[
                    "changed_by",
                ],
            )

        return (
            user,
            journey,
            generated_password,
        )


class StartAdaptationForm(forms.Form):
    probation_start_date = forms.DateField(
        label="Дата старта ИС",
        initial=timezone.localdate,
        widget=forms.DateInput(
            attrs={
                "type": "date",
            },
        ),
    )

    current_stage = forms.ModelChoiceField(
        label="Текущий этап",
        queryset=TraineeStage.objects.none(),
        widget=forms.Select(
            attrs={
                "class": "form-select",
            },
        ),
    )

    comment = forms.CharField(
        label="Комментарий",
        required=False,
        widget=forms.Textarea(
            attrs={
                "rows": 3,
            },
        ),
    )

    def __init__(
        self,
        *args,
        user,
        **kwargs,
    ):
        self.user = user

        super().__init__(
            *args,
            **kwargs,
        )

        for field_name in (
            "probation_start_date",
            "current_stage",
            "comment",
        ):
            field = self.fields[field_name]

            current_class = (
                field.widget.attrs.get(
                    "class",
                    "",
                )
            )

            field.widget.attrs["class"] = (
                f"{current_class} trainee-start-control"
            ).strip()

        available_stages = (
            TraineeStage.objects
            .filter(
                is_active=True,
                applies_to_internal_transfer=True,
            )
            .order_by("order")
        )

        self.fields[
            "current_stage"
        ].queryset = available_stages

        if not self.is_bound:
            first_stage = available_stages.first()

            if first_stage is not None:
                self.initial[
                    "current_stage"
                ] = first_stage

    def clean(self):
        cleaned_data = super().clean()

        if not self.user.is_active:
            raise forms.ValidationError(
                (
                    "Нельзя начать адаптацию: "
                    "аккаунт сотрудника отключён."
                ),
            )

        probation_start_date = cleaned_data.get(
            "probation_start_date",
        )
        current_stage = cleaned_data.get(
            "current_stage",
        )

        if TraineeJourney.objects.filter(
            user=self.user,
        ).exists():
            raise forms.ValidationError(
                "Адаптация для этого сотрудника уже начата.",
            )

        if (
            probation_start_date
            and probation_start_date
            > timezone.localdate()
        ):
            self.add_error(
                "probation_start_date",
                (
                    "Дата начала испытательного срока "
                    "не может быть в будущем."
                ),
            )

        if (
            current_stage
            and not current_stage.applies_to_entry_type(
                EntryType.INTERNAL_TRANSFER,
            )
        ):
            self.add_error(
                "current_stage",
                (
                    "Этот этап не применим "
                    "к внутреннему переходу."
                ),
            )

        return cleaned_data

    @transaction.atomic
    def save(
        self,
        *,
        changed_by=None,
    ):
        journey = TraineeJourney.objects.create(
            user=self.user,
            entry_type=EntryType.INTERNAL_TRANSFER,
            probation_start_date=(
                self.cleaned_data[
                    "probation_start_date"
                ]
            ),
            current_stage=(
                self.cleaned_data[
                    "current_stage"
                ]
            ),
            stage_started_at=(
                self.cleaned_data[
                    "probation_start_date"
                ]
            ),
            comment=self.cleaned_data.get(
                "comment",
                "",
            ),
        )

        initial_history = (
            journey.stage_history
            .filter(
                stage=journey.current_stage,
                ended_at__isnull=True,
            )
            .first()
        )

        if (
            initial_history is not None
            and changed_by is not None
        ):
            initial_history.changed_by = changed_by

            initial_history.save(
                update_fields=[
                    "changed_by",
                ],
            )

        return journey


class EditTraineeForm(forms.Form):
    first_name = forms.CharField(
        label="Имя",
        max_length=150,
    )

    last_name = forms.CharField(
        label="Фамилия",
        max_length=150,
    )

    entry_type = forms.ChoiceField(
        label="Тип входа",
        choices=EntryType.choices,
        widget=forms.RadioSelect,
    )

    probation_start_date = forms.DateField(
        label="Дата старта ИС",
        widget=forms.DateInput(
            attrs={
                "type": "date",
            },
        ),
    )

    comment = forms.CharField(
        label="Комментарий наставника",
        required=False,
        widget=forms.Textarea(
            attrs={
                "rows": 4,
            },
        ),
    )

    is_active = forms.BooleanField(
        label="Аккаунт активен",
        required=False,
    )

    def __init__(
        self,
        *args,
        journey,
        **kwargs,
    ):
        self.journey = journey

        super().__init__(
            *args,
            **kwargs,
        )

        if not self.is_bound:
            self.initial.update({
                "first_name": (
                    journey.user.first_name
                ),
                "last_name": (
                    journey.user.last_name
                ),
                "entry_type": (
                    journey.entry_type
                ),
                "probation_start_date": (
                    journey.probation_start_date
                ),
                "comment": journey.comment,
                "is_active": (
                    journey.user.is_active
                ),
            })

    def _can_shift_initial_stage_start(self):
        """
        Если сотрудник ещё ни разу не переходил
        между этапами, изменение даты начала ИС
        также меняет дату начала первого этапа.
        """
        if (
            self.journey.stage_started_at
            != self.journey.probation_start_date
        ):
            return False

        history_entries = (
            self.journey.stage_history
            .filter(
                stage=self.journey.current_stage,
                ended_at__isnull=True,
            )
        )

        return (
            self.journey.stage_history.count() == 1
            and history_entries.exists()
        )

    def clean(self):
        cleaned_data = super().clean()

        entry_type = cleaned_data.get(
            "entry_type",
        )

        probation_start_date = (
            cleaned_data.get(
                "probation_start_date",
            )
        )

        if (
            entry_type
            and not (
                self.journey.current_stage
                .applies_to_entry_type(
                    entry_type,
                )
            )
        ):
            self.add_error(
                "entry_type",
                (
                    "Текущий этап не применим "
                    "к выбранному типу входа."
                ),
            )

        if (
            probation_start_date
            and probation_start_date
            > timezone.localdate()
        ):
            self.add_error(
                "probation_start_date",
                (
                    "Дата начала испытательного срока "
                    "не может быть в будущем."
                ),
            )

        if (
            probation_start_date
            and not (
                self._can_shift_initial_stage_start()
            )
            and probation_start_date
            > self.journey.stage_started_at
        ):
            self.add_error(
                "probation_start_date",
                (
                    "Дата начала испытательного срока "
                    "не может быть позже начала "
                    "текущего этапа."
                ),
            )

        return cleaned_data

    @transaction.atomic
    def save(self):
        journey = self.journey
        user = journey.user

        old_probation_start_date = (
            journey.probation_start_date
        )

        new_probation_start_date = (
            self.cleaned_data[
                "probation_start_date"
            ]
        )

        shift_initial_stage = (
            self._can_shift_initial_stage_start()
            and (
                old_probation_start_date
                != new_probation_start_date
            )
        )

        user.first_name = self.cleaned_data[
            "first_name"
        ]
        user.last_name = self.cleaned_data[
            "last_name"
        ]
        user.is_active = self.cleaned_data[
            "is_active"
        ]

        user.save(
            update_fields=[
                "first_name",
                "last_name",
                "is_active",
            ],
        )

        journey.entry_type = self.cleaned_data[
            "entry_type"
        ]
        journey.probation_start_date = (
            new_probation_start_date
        )
        journey.comment = self.cleaned_data.get(
            "comment",
            "",
        )

        update_fields = [
            "entry_type",
            "probation_start_date",
            "comment",
        ]

        if shift_initial_stage:
            journey.stage_started_at = (
                new_probation_start_date
            )

            update_fields.append(
                "stage_started_at",
            )

        journey.full_clean()

        journey.save(
            update_fields=update_fields,
        )

        if shift_initial_stage:
            journey.stage_history.filter(
                stage=journey.current_stage,
                ended_at__isnull=True,
            ).update(
                started_at=(
                    new_probation_start_date
                ),
            )

        return journey
